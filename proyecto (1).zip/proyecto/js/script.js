// Smooth scrolling
document.querySelectorAll('a[href^="#"]').forEach(anchor => {
    anchor.addEventListener('click', function (e) {
        e.preventDefault();

        document.querySelector(this.getAttribute('href')).scrollIntoView({
            behavior: 'smooth'
        });
    });
});

document.addEventListener('DOMContentLoaded', function() {
    var items = document.querySelectorAll('#menu .list-group-item');
    items.forEach(function(item) {
      item.addEventListener('click', function() {
        // Remover la clase 'active' de todos los elementos
        items.forEach(function(i) {
          i.classList.remove('active');
        });
        // Agregar la clase 'active' al elemento clicado
        this.classList.add('active');
      });
    });
  });